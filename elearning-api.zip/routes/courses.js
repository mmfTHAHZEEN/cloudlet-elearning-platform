const express = require('express');
const { db, uuid } = require('../data/store');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/courses  (public - browse catalog)
router.get('/', (req, res) => {
  res.json([...db.courses.values()]);
});

// GET /api/courses/:id
router.get('/:id', (req, res) => {
  const course = db.courses.get(req.params.id);
  if (!course) return res.status(404).json({ error: 'Course not found' });
  res.json(course);
});

// POST /api/courses  (instructor only)
router.post('/', authenticate, requireRole('instructor'), (req, res) => {
  const { title, description, videoUrl } = req.body;
  if (!title) return res.status(400).json({ error: 'title is required' });

  const id = uuid();
  const course = { id, title, description: description || '', instructorId: req.user.id, videoUrl: videoUrl || null };
  db.courses.set(id, course);
  res.status(201).json(course);
});

// POST /api/courses/:id/enroll  (student)
router.post('/:id/enroll', authenticate, (req, res) => {
  const course = db.courses.get(req.params.id);
  if (!course) return res.status(404).json({ error: 'Course not found' });

  const already = [...db.enrollments.values()]
    .find(e => e.userId === req.user.id && e.courseId === course.id);
  if (already) return res.status(200).json(already);

  const id = uuid();
  const enrollment = { id, userId: req.user.id, courseId: course.id, enrolledAt: new Date().toISOString() };
  db.enrollments.set(id, enrollment);
  res.status(201).json(enrollment);
});

// GET /api/courses/:id/students (instructor - roster)
router.get('/:id/students', authenticate, requireRole('instructor'), (req, res) => {
  const roster = [...db.enrollments.values()]
    .filter(e => e.courseId === req.params.id)
    .map(e => {
      const u = db.users.get(e.userId);
      return { userId: e.userId, name: u?.name, email: u?.email, enrolledAt: e.enrolledAt };
    });
  res.json(roster);
});

module.exports = router;
